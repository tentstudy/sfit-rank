<!DOCTYPE html>
<html lang="vi-VN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap-3.1.1-dist/css/bootstrap.min.css" />
    <title>Document</title>
    <style>
        #choose-file {
            display: none;
        }
        .col-right .list-group {
            max-height: calc(100vh - 90px);
            overflow-x: overlay;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <h1 class="text-center">Nop bai</h1>
        </div>
        <div class="col-md-7 col-xs-8">
            <div class="form-group">
                <label for="">Chọn bài</label>
                <select class="form-control">
                    <option>Bai 1</option>
                    <option>Bai 2</option>
                    <option>Bai 3</option>
                    <option>Bai 4</option>
                    <option>Bai 5</option>
                </select>
            </div>
            <div class="form-group">
                <label for="choose-file">
                    <a type="button" class="btn btn-default">
                        <span class="glyphicon glyphicon-folder-open"></span>
                        Chọn file
                    </a>
                </label>
                <input type="file" id="choose-file" accept=".html,.php,.zip,.rar" />
                <span id="choosed-file">Không có file nào được chọn</span>
            </div>
            <div class="form-group">
                <a class="btn btn-primary">Nộp bài</a>
            </div>
        </div>   
        <div class="col-md-5 col-xs-4 col-right">
            <ul class="list-group">
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
                <li class="list-group-item clearfix">
                    <div class="pull-left">
                        <h5>Bai 1</h5>
                        <small>10 gio truoc</small>
                    </div>
                    <a href="#" target="_blank" class="btn btn-primary pull-right">Xem</a>
                </li>
            </ul>
        </div>   
    </div>
    <script src="js/jquery.min.js"></script>
    <script>
        $(document).ready(() => {
            $('#choose-file').on('change', (e) => {
                $('#choosed-file').text($(e.target).val().split("\\")[2]);
            });
        });
    </script>
</body>
</html>