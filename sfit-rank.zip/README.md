# Sfit - rank
<h3>Với mong muốn khiến bot tràn ngập câu lạ bộ</h3>

Hệ thống xếp hạng thành viên cho clb SFIT - UTC
- Xếp hạng theo các khoảng thời gian 1 ngafym 7 ngày, 30 ngày.
- Tùy chỉnh điểm theo bài post, cmt, reactions (like, love, haha...).
- Có danh sách những bài viết không được tính rank.
