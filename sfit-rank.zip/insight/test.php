<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="../css/insight.css">
	<link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css">
</head>
<body>
<div class="container">
	<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
		<table class="table table-hover">
			<thead>
				<tr>
					<th></th>
					<th class="text-center">Key</th>
					<th class="text-center">Value</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<th><i class="fa fa-check-square-o"></i></th>
					<td><input type="text" name="" id="input" class="form-control" value="" required="required" pattern="" title=""></td>
					<td><input type="text" name="" id="input" class="form-control" value="" required="required" pattern="" title=""></td>
				</tr>
				<tr>
					<th><i class="fa fa-check-square-o"></i></th>
					<td><input type="text" name="" id="input" class="form-control" value="" required="required" pattern="" title=""></td>
					<td><input type="text" name="" id="input" class="form-control" value="" required="required" pattern="" title=""></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
</body>
</html>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="test.js"></script>