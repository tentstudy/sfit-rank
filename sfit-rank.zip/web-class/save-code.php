<pre>
<?php require_once '../check-login.php'; ?>
<?php
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    if ( !isset($_POST["submit"]) || empty($_FILES["fileToUpload"])) {
        echo "lỗi";
        exit();
    }
    $uploadOk = 1;
    $file = $_FILES["fileToUpload"];
    /*kiểm tra dung lượng*/
    if ($file["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    /*kiểm tra định dạng*/
    // $fomat = explode($file["name"])
    $pathStorage = "storage/";
    // $fileName = str_replace(array(
    //     '.php', '.html', '.htm', '.phtml'
    // ), '', basename($file["name"]));
    $fileName = $_REQUEST['exercises'] ?? 'error';
    $time = strtotime("now");
    echo $time;
    $fileName = "{$fileName}_{$userId}_{$time}.html";
    print_r($_FILES);
    echo('xong');
    $pathDir = "storage/";
    $pathFile = $pathDir . $fileName;
    /*kiểm tra file đã tồn tại hay chưa*/
    if (file_exists($pathFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $pathFile)) {
            echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
    header('Location: ./');
// $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
// if(isset()) {
    // $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    // if($check !== false) {
    //     echo "File is an image - " . $check["mime"] . ".";
    //     $uploadOk = 1;
    // } else {
    //     echo "File is not an image.";
    //     $uploadOk = 0;
    // }
// }
// // Allow certain file formats
// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
// && $imageFileType != "gif" ) {
//     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
//     $uploadOk = 0;
// }
// Check if $uploadOk is set to 0 by an error

?>