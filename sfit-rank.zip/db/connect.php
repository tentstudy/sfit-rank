<?php
/*
 * gồm bảng user: user_id, user_name
 * 
 * 

 */
	require_once __DIR__ . '/config.php';
	require_once __DIR__ . '/query.php';
	$db = new DB();
?>