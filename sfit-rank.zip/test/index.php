<script src="jquery.min.js"></script>
<script src="fb.js"></script>
<script src="check-hashtag.js"></script>